#include "mbed.h"

PwmOut PWM1(p21);

DigitalOut myled(LED1);

int main() {
    while(1) {
        myled = 1;
        PWM1.period(0.010);
        PWM1 = 0.8;
        
        wait(0.2);
        myled = 0;
        wait(0.2);
    }
}
